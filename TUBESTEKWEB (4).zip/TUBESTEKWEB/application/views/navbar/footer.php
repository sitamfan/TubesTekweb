        <!-- Bootstrap core JS-->
        <script src="<?= site_url('assets/');?>https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="<?= site_url('assets/');?>js/scripts.js"></script>
    </body>
</html>